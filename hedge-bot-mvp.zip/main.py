from utils.telegram import send_telegram_message

if __name__ == "__main__":
    send_telegram_message("🚀 Bot iniciado com sucesso!")